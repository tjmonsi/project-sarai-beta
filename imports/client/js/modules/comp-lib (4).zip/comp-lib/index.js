import actions from './v2/actions';
import routes from './v2/routes';
export * from './v2';

export default {
  actions,
  load: () => null,
  routes
};
